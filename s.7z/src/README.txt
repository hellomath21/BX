compile:

///////////  windows mingw
rm -rf build && mkdir build
cd build
cmake -DBUILD_SHARED_LIBS=TRUE -G "MinGW Makefiles" ..
make -j8 && make install

///////////  windows Visual C++
open vc x64 shell
path=D:/Yolsa/Android/opencv32_vc;D:/Yolsa/Android/opencv32_vc/x64/vc14/bin;D:/Yolsa/Android/opencv32_vc/x64/vc14/lib;D:/Yolsa/Android/opencv32_vc/include;D:/Yolsa/Android/opencv32_vc/include/opencv;D:/Yolsa/Android/opencv32_vc/include/opencv2;D:/Yolsa/download/tmp/tools;D:/Yolsa/Android/cmake-3.9.0-win32-x86/bin;%path%

rm -rf build && mkdir build
cd build
cmake -DCMAKE_WINDOWS_EXPORT_ALL_SYMBOLS=TRUE -DBUILD_SHARED_LIBS=TRUE -G "NMake Makefiles"  ..
nmake && nmake install

///////////  linux ubuntu
rm -rf build && mkdir build
cd build
rm -rf * && cmake ..
make -j8 && make install

///////////  arm
rm -rf build && mkdir build
cd build
rm -rf * && cmake -DCMAKE_TOOLCHAIN_FILE:PATH="./toolchain.cmake" ..
make -j8 && make install

///////////  ubuntu mingw64
rm -rf build && mkdir build
cd build
rm -rf * && cmake -DCMAKE_TOOLCHAIN_FILE=../toolchain_ubuntu_mingw64.cmake ..
make -j8 && make install

///////////  ubuntu ndk
export ANDROID_NDK=~/Android/Sdk/ndk-bundle

rm -rf build && mkdir build
cd build
rm -rf * && cmake -DCMAKE_TOOLCHAIN_FILE=$ANDROID_NDK/build/cmake/android.toolchain.cmake -DANDROID_ABI=armeabi-v7a ..
#rm -rf * && cmake -DCMAKE_TOOLCHAIN_FILE=$ANDROID_NDK/build/cmake/android.toolchain.cmake -DANDROID_ABI="armeabi-v7a" -DANDROID_ARM_NEON=ON -DANDROID_PLATFORM=android-17 ..
#rm -rf * && cmake -DCMAKE_TOOLCHAIN_FILE=~/Android/Sdk/ndk-bundle/build/cmake/android.toolchain.cmake ..
make -j8 && make install


///////////  ubuntu cuda


