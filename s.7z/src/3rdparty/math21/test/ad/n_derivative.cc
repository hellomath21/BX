/* Copyright 2015 The math21 Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/

#include "n_derivative.h"

namespace math21 {
    namespace ad {
        // sin(x): x, sin(x), dy=1, dx
//        void test_n_derivative_sin() {
//            ad::Variable::setRequestedAbstractLevel(1);
//            ad::Function::setSetSizeFlag(0);
//            Set X;
//            Set V;
//            NumN y;
//            VariableMap data(V);
//            NumN x = data.createV("x");
//            Variable &vx = data.at(x);
//            vx.setType(variable_type_input);
//            vx.getValue().setSize(2);
//            vx.getValue() = 2, 3.14;
////            vx.getValue().setSize(1);
////            vx.getValue() = 3.14;
//            Set input;
//            input.add(x);
//            X.add(input);
//
////            NumN x_dummy = data.createV("x_dummy");
////            Variable &vx_dummy = data.at(x_dummy);
////            vx_dummy.setType(variable_type_input);
////            vx_dummy.getValue().setSize(2);
////            vx_dummy.getValue() = 2, 3.14;
////            X.add(x_dummy);
//
//            Set output;
//            op_mat_sin sin;
//            sin.f(input, output, data);
//
//            y = output(1);
//            Variable &vy = data.at(y);
//            vy.setType(variable_type_output);
//
//            // set size
//            Set Y;
//            Y.add(y);
//
//            NumN n = 1;
////            NumN n = 2;
////            NumN n = 20;
//            Derivative d(data);
//            Map dX;
//            for (NumN i = 1; i <= n; ++i) {
//                d.cds(X, y, V, dX, i);
//                y = dX.getY()(1);
//                Y.add(y);
//            }
//
//            d.fvs(X, Y, V);
//
//            X.log("X");
//            Y.log("Y");
//            V.log("V");
//            dX.log("dX");
//            data.log("data666");
//        }
//
//        // 2*sin(x): x, sin(x), dy=1, dx
//        void test_n_derivative_2_sin() {
////            ad::Variable::setRequestedAbstractLevel(1);
////            ad::Function::setSetSizeFlag(0);
//            Set X;
//            Set V;
//            NumN y;
//            VariableMap data(V);
//            NumN x = data.createV("x");
//            Variable &vx = data.at(x);
//            vx.setType(variable_type_input);
//            vx.getValue().setSize(2);
//            vx.getValue() = 2, 3.14;
////            vx.getValue().setSize(1);
////            vx.getValue() = 3.14;
//            Set input;
//            input.add(x);
//            X.add(input);
//
//            Set output;
//            op_num_sin sin;
//            sin.f(input, output, data);
//
//            output.copyTo(input);
//            op_vec_multiply multiply;
//            NumN k = data.createC(2, "2");
//            if (Function::isSetSize()) {
//                setSizeyByx(input(1), k, data);
//            }
//            input.add(k);
//            multiply.f(input, output, data);
//
//            y = output(1);
//            Variable &vy = data.at(y);
//            vy.setType(variable_type_output);
//
//            Set Y;
//            Y.add(y);
//
////            NumN n = 1;
//            NumN n = 20;
//            Derivative d(data);
//            Map dX;
//            for (NumN i = 1; i <= n; ++i) {
//                d.cds(X, y, V, dX, i);
//                if (!dX.get(x, y)) {
//                    MATH21_ASSERT(0);
//                }
//            }
//
//            Y.add(y);
//            d.fvs(X, Y, V);
//
//            X.log("X");
//            Y.log("Y");
//            V.log("V");
//            dX.log("dX");
//            data.log("data");
//        }
//
//
//        // sin(cos(x)): x, sin(x), dy=1, dx
//        void test_n_derivative_sin_cos() {
//            Set X;
//            Set V;
//            NumN y;
//            VariableMap data(V);
//            NumN x = data.createV();
//            Variable &vx = data.at(x);
//            vx.getValue().setSize(3);
//            vx.getValue() = 1, 2, 3.14;
//            Set input;
//            input.add(x);
//            X.add(input);
//
//            Set output;
//            op_mat_cos cos;
//            cos.f(input, output, data);
//            output.copyTo(input);
//
//            op_mat_sin sin;
//            sin.f(input, output, data);
//            y = output(1);
//
//
////            NumN n = 1;
////            NumN n = 3;
//            NumN n = 7;
//            Derivative d(data);
//            Map dX;
//            for (NumN i = 1; i <= n; ++i) {
//                d.cds(X, y, V, dX, i);
//                if (!dX.get(x, y)) {
//                    MATH21_ASSERT(0);
//                }
//            }
//
//            Set Y;
//            Y.add(y);
//            d.fvs(X, Y, V);
//
//            X.log("X");
//            Y.log("Y");
//            data(y).log("dx");
////            V.log("V");
//            dX.log("dX");
////            data.log("data");
//        }
//
//
//        // 2*cos(sin(cos(x))): x, sin(x), dy=1, dx
//        void test_n_derivative_2_cos_sin_cos() {
//            Set X;
//            Set V;
//            NumN y;
//            VariableMap data(V);
//            NumN x = data.createV();
//            Variable &vx = data.at(x);
////            vx.getValue().setSize(1);
////            vx.getValue() = 3.14;
//            vx.getValue().setSize(2);
//            vx.getValue() = 2, 3.14;
//            Set input;
//            input.add(x);
//            X.add(input);
//
//            Set output;
//            op_mat_cos cos;
//            cos.f(input, output, data);
//            output.copyTo(input);
//
//            op_mat_sin sin;
//            sin.f(input, output, data);
//            output.copyTo(input);
//
//            cos.f(input, output, data);
//            output.copyTo(input);
//
//            op_vec_multiply multiply;
//            NumN k = data.createC(2, "2");
//            if (Function::isSetSize()) {
//                setSizeyByx(input(1), k, data);
//            }
//            input.add(k);
//            multiply.f(input, output, data);
//            y = output(1);
//
////            NumN n = 1;
////            NumN n = 3;
//            NumN n = 7;
//            Derivative d(data);
//            Map dX;
//            for (NumN i = 1; i <= n; ++i) {
//                d.cds(X, y, V, dX, i);
//                if (!dX.get(x, y)) {
//                    MATH21_ASSERT(0);
//                }
//            }
//
//            Set Y;
//            Y.add(y);
//            d.fvs(X, Y, V);
//
//            data(y).log("dx");
////            X.log("X");
////            Y.log("Y");
////            V.log("V");
////            dX.log("dX");
////            data.log("data");
//        }

//        // y = x1*x1 + x2*x3, (10, 2, 3)
//        void test_n_derivative_num_add_and_multiply() {
//            ad::Variable::setRequestedAbstractLevel(0);
//            ad::Function::setSetSizeFlag(0);
//            Set V;
//            VariableMap data(V);
//            NumN x1 = data.createV("x1");
//            Variable &vx1 = data.at(x1);
//            vx1.getValue().setSize(1);
//            vx1.getValue() = 10;
//
//            NumN x2 = data.createV("x2");
//            Variable &vx2 = data.at(x2);
//            vx2.getValue().setSize(1);
//            vx2.getValue() = 2;
//
//            NumN x3 = data.createV("x3");
//            Variable &vx3 = data.at(x3);
//            vx3.getValue().setSize(1);
//            vx3.getValue() = 3;
//
//            op_num_assign assign0;
//            Function &assign = assign0;
//            op_num_add add0;
//            Function &add = add0;
//            op_num_multiply multiply0;
//            Function &multiply = multiply0;
//
//            NumN x11, x12;
//            assign.f(x1, x11, data);
//            assign.f(x1, x12, data);
//
//            NumN x1_x1;
//            NumN x2_x3;
//            multiply.f(x11, x12, x1_x1, data);
//            multiply.f(x2, x3, x2_x3, data);
//
//            NumN y;
//            add.f(x1_x1, x2_x3, y, data);
//
//            Variable &vy = data.at(y);
//            vy.setType(variable_type_output);
//
//            Set X;
//            Set Y;
//            X.add(x1);
//            X.add(x2);
//            X.add(x3);
//            Y.add(y);
//
//            Derivative d(data);
//            Map dX;
//
//            d.compute(X, Y, V);
////    X.log("X");
////    Y.log("Y");
////    V.log("V");
////    dX.log("dX");
////    data.log("data666");
//
////    NumN n = 0;
////            NumN n = 2;
//            NumN n = 3;
////    NumN n = 20;
//
//            Set X_cd;
//            X_cd.add(x1);
////            X_cd.add(X);
//            for (NumN i = 1; i <= n; ++i) {
//                if (y == 0) {
//                    break;
//                }
//                d.cds(X_cd, y, V, dX, i);
//                y = dX.getY()(1);
//                Y.add(y);
//
////        if (i != 3) {
//                d.compute(X, Y, V);
////        }
//                if (i == 3) {
//                    X.log("X");
//                    Y.log("Y");
//                    V.log("V");
//                    dX.log("dX");
//                    data.log("data666");
//                }
//
//            }
//        }

        // y = x1*x1 + x2*x3, (10, 2, 3)
        void test_n_derivative_num_add_and_multiply_2() {
            ad::Variable::setRequestedAbstractLevel(0);
            ad::Function::setSetSizeFlag(0);
//            Set V;
//            VariableMap data(V);

            VariableMap &data = ad_get_data();
            Set &V = data.getV();

            auto point1 = ad_create_point_var("x1");
            ad_get_value(point1).setSize(1);
            ad_get_value(point1) = 10;

            auto point2 = ad_create_point_var("x2");
            ad_get_value(point2).setSize(1);
            ad_get_value(point2) = 2;

            auto point3 = ad_create_point_var("x3");
            ad_get_value(point3).setSize(1);
            ad_get_value(point3) = 3;

            auto point11 = ad_num_assign(point1);
            auto point12 = ad_num_assign(point1);

//            auto point1_point1 = point11 * point12;
//            auto point2_point3 = point2 * point3;
//            auto pointy = point1_point1 + point2_point3;

//            auto pointy = (point11 * point12) + (point2 * point3);

            auto point1_point1 = ad_num_mul(point11, point12);
            auto point2_point3 = ad_num_mul(point2, point3);
            auto pointy = ad_num_add(point1_point1, point2_point3);
            NumN y;
            y = pointy.id;

            Variable &vy = data.at(y);
            vy.setType(variable_type_output);

            Set X;
            Set Y;
            X.add(point1.id);
            X.add(point2.id);
            X.add(point3.id);
            Y.add(y);

            Derivative d(data);
            Map dX;

            d.compute(X, Y, V);
//    X.log("X");
//    Y.log("Y");
//    V.log("V");
//    dX.log("dX");
//    data.log("data666");

//    NumN n = 0;
//            NumN n = 2;
            NumN n = 3;
//    NumN n = 20;

            Set X_cd;
            X_cd.add(point1.id);
//            X_cd.add(X);
            for (NumN i = 1; i <= n; ++i) {
                if (y == 0) {
                    break;
                }
                d.cds(X_cd, y, V, dX, i);
//                y = dX.getY()(1);
                y = dX.valueAt(X_cd(1));
                Y.add(y);

//        if (i != 3) {
                d.compute(X, Y, V);
//        }
                if (i == 3) {
                    X.log("X");
                    Y.log("Y");
                    V.log("V");
                    dX.log("dX");
                    data.log("data666");
                }

            }
        }

        // (5, 2, 1)
        // y = x*x*x + k2*x*x + k3*x, 125 + 50 + 5 = 180
        // d1(y) = 3*x*x + 2*k2*x + k3, 75 + 20 + 1 = 96
        // d2(y) = 6*x + 2*k2, 30 + 4 = 34
        // d3(y) = 6
        void test_n_derivative_num_add_and_multiply_3() {
            ad::Variable::setRequestedAbstractLevel(0);
            ad::Function::setSetSizeFlag(0);
//            Set V;
//            VariableMap data(V);

            VariableMap &data = ad_get_data();
            Set &V = data.getV();

            auto point1 = ad_create_point_var("x");
            ad_get_value(point1).setSize(1);
            ad_get_value(point1) = 5;

            auto point2 = ad_create_point_var("k2");
            ad_get_value(point2).setSize(1);
            ad_get_value(point2) = 2;

            auto point3 = ad_create_point_var("k3");
            ad_get_value(point3).setSize(1);
            ad_get_value(point3) = 1;

            auto point11 = ad_num_assign(point1);
            auto point12 = ad_num_assign(point1);
            auto point13 = ad_num_assign(point1);

            auto p1 = ad_num_mul(point11, point12, point13);
            auto p2 = ad_num_mul(point2, point12, point13);
            auto p3 = ad_num_mul(point3, point1);
            auto pointy = ad_num_add(p1, p2, p3);
            NumN y;
            y = pointy.id;

            Variable &vy = data.at(y);
            vy.setType(variable_type_output);

            Set X;
            Set Y;
            X.add(point1.id);
            X.add(point2.id);
            X.add(point3.id);
            Y.add(y);

            Derivative d(data);
            Map dX;

            d.compute(X, Y, V);
            NumN n = 3;

            Set X_cd;
            X_cd.add(point1.id);
//            X_cd.add(X);
            for (NumN i = 1; i <= n; ++i) {
                if (y == 0) {
                    break;
                }
                d.cds(X_cd, y, V, dX, i);
                y = dX.valueAt(X_cd(1));
                Y.add(y);

//        if (i != 3) {
                d.compute(X, Y, V);
//        }
                if (i == 3) {
                    X.log("X");
                    Y.log("Y");
                    V.log("V");
                    dX.log("dX");
//                    data.log("data666");
                }

            }

            for (NumN i = 1; i <= Y.size(); ++i) {
                data(Y(i)).log(math21_string_to_string(i).c_str());
            }

        }

        // sin(x): x, sin(x), dy=1, dx
        void test_n_derivative_sin_dbr() {
//            ad::Variable::setRequestedAbstractLevel(1);
            ad::Variable::setRequestedAbstractLevel(0);
            VariableMap &data = ad_get_data();

            auto x = ad_create_point_var("x");
            Variable &vx = ad_get_variable(x);
            vx.setType(variable_type_input);
            vx.getValue().setSize(2);
            vx.getValue() = MATH21_PI / 2, MATH21_PI;
//            vx.getValue().setSize(1);
//            vx.getValue() = MATH21_PI / 2;
            vx.synchronizeToZero(data);

            auto y = 3 * ad_sin(x);

//            auto y1 = ad_num_sin(x);
//            auto y = ad_num_sin(x);
            y = ad_sum(y);
            y.log("0", 15);
            NumN n = 1;
//            NumN n = 2;
//            NumN n = 3;
//            NumN n = 0;
            for (NumN i = 1; i <= n; ++i) {
                y = grad(x, y);
                if (y.id == 0) {
                    m21log("f=0, so stop computing f'");
                    m21log("i", i);
                    break;
                }
                y.log(math21_string_to_string(i).c_str(), 15);
            }
        }

        // tanh(x)
        void test_n_derivative_tanh_dbr() {
//            ad::Variable::setRequestedAbstractLevel(1);
            ad::Variable::setRequestedAbstractLevel(0);
            VariableMap &data = ad_get_data();

            auto x = ad_create_point_var("x");
            Variable &vx = ad_get_variable(x);
            vx.setType(variable_type_input);
            vx.getValue().setSize(1);
            vx.getValue() = 1.0;
            vx.synchronizeToZero(data);

            auto y = tanh(x);
            y.log("0", 15);
            NumN n = 1;
//            NumN n = 2;
//            NumN n = 3;
//            NumN n = 6;
            for (NumN i = 1; i <= n; ++i) {
                y = grad(x, y);
                if (y.id == 0) {
                    m21log("f=0, so stop computing f'");
                    m21log("i", i);
                    break;
                }
                y.log(math21_string_to_string(i).c_str(), 15);
            }

            // finite differences
            auto y_fd = (tanh(1.0001) - tanh(0.9999)) / 0.0002;
            y_fd.log("y_fd", 15);
        }

        void test_n_derivative_mat_mul() {
            VariableMap &data = ad_get_data();

            auto w = ad_create_point_var("W");
            Variable &vw = ad_get_variable(w);
            vw.setType(variable_type_input);
            vw.getValue().setSize(2, 2);
            vw.getValue().letters();

            auto x = ad_create_point_var("X");
            Variable &vx = ad_get_variable(x);
            vx.setType(variable_type_input);
            vx.getValue().setSize(2, 2);
            vx.getValue() = 5, 6, 7, 8;

            auto y = ad_mat_mul(w, x);
            y.log("0-th order", 15);
            NumN n = 1;
//    NumN n = 2;
            for (NumN i = 1; i <= n; ++i) {
//        y = ad_grad(w, y);
                y = ad_jacobian(w, y);
                if (y.id == 0) {
                    m21log("f=0, so stop computing f'");
                    m21log("i order", i);
                    break;
                }
                y.log((math21_string_to_string(i)+"-th order").c_str(), 15);
            }
        }

        void test_n_derivative_all() {
//            test_n_derivative_sin();
//            test_n_derivative_2_sin();
//            test_n_derivative_sin_cos();
//            test_n_derivative_2_cos_sin_cos();
//            test_n_derivative_num_add_and_multiply();
//            test_n_derivative_num_add_and_multiply_2();
//            test_n_derivative_num_add_and_multiply_3();
//            test_n_derivative_sin_dbr();
//            test_n_derivative_tanh_dbr();

//            test_n_derivative_mat_mul();
        }
    }
}