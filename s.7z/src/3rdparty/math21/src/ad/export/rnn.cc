/* Copyright 2015 The math21 Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/

#include "01.h"
#include "02.h"
#include "rnn.h"

namespace math21 {
    namespace ad {
        template<typename T, typename FunType>
        void sgd_with_momentum(const FunType &grad, VecR &x, const FunType &callback = 0,
                               NumN num_iters = 200, NumR step_size = 0.1, NumR mass = 0.9) {
            // Stochastic gradient descent with momentum
            // grad() must have signature grad(x, g, i), where i is the iteration number.
            // x is input and output.
            VecR velocity(x.size());
            velocity = 0;
            NumN i;
            VecR g;
            for (i = 1; i <= num_iters; ++i) {
                grad(x, g, i);
                if (callback) {
                    callback(x, g, i);
                }
                // velocity = mass * velocity - (1.0 - mass) * g
                math21_operator_container_linear_to_A(mass, velocity, -(1.0 - mass), g);
                // x = x + step_size * velocity
                math21_operator_container_linear_to_A(1, x, step_size, velocity);
            }
        }

        // yf: yield function
        template<typename T>
        NumN yf_get_dim_i(const T &x, NumN i) {
            return ad_get_dim_i(x, i);
        }

        template<typename T>
        TenR &yf_get_value(const T &x) {
            return ad_get_value(x);
        }

        struct ad_rnn_params {
            ad_point params_1d, init_hiddens, change_para, predict_para;
        };

        void split_rnn_params(const ad_point &params_point, ad_rnn_params &params,
                              NumN input_size, NumN state_size, NumN output_size) {
            ad_point &params_1d = params.params_1d;
            ad_point &init_hiddens = params.init_hiddens;
            ad_point &change_para = params.change_para;
            ad_point &predict_para = params.predict_para;

            params_1d = params_point;

            NumN h_size = 1 * state_size;
            NumN wc_size = (input_size + state_size + 1) * state_size;

            init_hiddens = ad_vec_share_sub(params_1d, 1, h_size);
            change_para = ad_vec_share_sub(params_1d, h_size + 1, h_size + wc_size);
            predict_para = ad_vec_share_sub(params_1d, h_size + wc_size + 1, -1);
            VecN d(2);
            d = 1, state_size;
            init_hiddens = ad_share_reshape(init_hiddens, d);
            d = input_size + state_size + 1, state_size;
            change_para = ad_share_reshape(change_para, d);
            d = state_size + 1, output_size;
            predict_para = ad_share_reshape(predict_para, d);
        }

        ad_point create_ad_rnn_params(
                NumN input_size, NumN state_size, NumN output_size, NumR param_scale) {
            ad_rnn_params params;
            ad_point &params_1d = params.params_1d;
            ad_point &init_hiddens = params.init_hiddens;
            ad_point &change_para = params.change_para;
            ad_point &predict_para = params.predict_para;
            TenR h, wc, wp;
            h.setSize(1, state_size);
            wc.setSize(input_size + state_size + 1, state_size);
            wp.setSize(state_size + 1, output_size);
            RanNormal ranNormal;
            ranNormal.set(0, param_scale);
            math21_random_draw(h, ranNormal);
            math21_random_draw(wc, ranNormal);
            math21_random_draw(wp, ranNormal);

            VecR params_value(h.size() + wc.size() + wp.size());
            ad_point _params(params_value, 1);
            params_1d = _params;

            split_rnn_params(params_1d, params, input_size, state_size, output_size);

            ad_get_value(init_hiddens).assign(h);
            ad_get_value(change_para).assign(wc);
            ad_get_value(predict_para).assign(wp);
            return params_1d;
        }

        ad_point concat_and_multiply(const ad_point &weights, const Seqce<ad_point> &args) {
            Seqce<ad_point> xs(args.size() + 1);
            math21_operator_container_set_partially(args, xs, 0, 0, args.size());
            NumN nr = ad_get_dim_i(args(1), 1);
            MatR k_value(nr, 1);
            k_value = 1;
            xs(xs.size()) = k_value;
            auto cat_state = ad_concatenate(xs, 2);
            return ad_mat_mul(cat_state, weights);
        }

// x: num_sequences, input_size
// h: num_sequences, state_size
// 1: num_sequences, 1
// wx: input_size, state_size
// wh: state_size, state_size
// b: 1, state_size
// (x, h, 1): num_sequences, (input_size + state_size +1)
// paras: input_size + state_size + 1, state_size
// h = x*wx + h*wh + b
//   = (x, h, 1) * (wx,
//                  wh,
//                  b)
        ad_point update_f(const ad_point &input, const ad_point &hiddens, const ad_point &change_para) {
            Seqce<ad_point> args;
            args.push(input);
            args.push(hiddens);
            return ad_tanh(concat_and_multiply(change_para, args));
        }

// hiddens: num_sequences * state_size
// paras: state_size + 1, output_size
// output: num_sequences * output_size
        ad_point hiddens_to_output_probs(const ad_point &hiddens, const ad_point &predict_para) {
            Seqce<ad_point> args;
            args.push(hiddens);
            auto output = concat_and_multiply(predict_para, args);
            VecN axes(1);
            axes = 2;
            return output - ad_logsumexp(output, axes, 1); // Normalize log-probs
        }

        ad_point ad_rnn_predict(const ad_point &params_point, const ad_point &data_inputs,
                                NumN input_size, NumN state_size, NumN output_size) {
            ad_rnn_params params;
            split_rnn_params(params_point, params, input_size, state_size, output_size);

            const ad_point &params_1d = params.params_1d;
            const ad_point &init_hiddens = params.init_hiddens;
            const ad_point &change_para = params.change_para;
            const ad_point &predict_para = params.predict_para;

            NumN num_sequences = yf_get_dim_i(data_inputs, 2);
            // hiddens: num_sequences, state_size
            auto hiddens = ad_repeat(init_hiddens, num_sequences, 1);
            auto output = hiddens_to_output_probs(hiddens, predict_para);
            _Set<ad_point> pack_input;
            pack_input.add(output);
            if (yf_get_dim_i(data_inputs, 1) > 0) {
                _Set<ad_point> input_s;
                ad_row_unpack(data_inputs, input_s);
                for (NumN i = 1; i <= input_s.size(); ++i) { // Iterate over time steps.
                    auto input = input_s(i);
                    hiddens = update_f(input, hiddens, change_para);
                    output = hiddens_to_output_probs(hiddens, predict_para);
                    pack_input.add(output);
                }
            }
            // output: time_steps * num_sequences * output_size
            output = ad_row_pack(pack_input);
            return output;
        }

        ad_point ad_rnn_log_likelihood(
                const ad_point &params_point, const ad_point &data_inputs, const ad_point &data_targets,
                NumN input_size, NumN state_size, NumN output_size) {
            auto logprobs = ad_rnn_predict(params_point, data_inputs, input_size, state_size, output_size);
            return ad_rnn_part_log_likelihood(logprobs, data_targets);
        }

        ad_point ad_rnn_part_log_likelihood(const ad_point &logprobs0, const ad_point &data_targets) {
            NumN num_time_steps = ad_get_dim_i(data_targets, 1);
            NumN num_examples = ad_get_dim_i(data_targets, 2);
            NumN logprobs_dim1 = ad_get_dim_i(logprobs0, 1);

            // not include the last time step
            auto logprobs = ad_axis_i_sub_get(logprobs0, 0, logprobs_dim1 - 1, 1);
            auto loglik = ad_inner_product(logprobs, data_targets);
            NumR denominator = num_time_steps * num_examples;
            MATH21_ASSERT(denominator)
            return loglik / denominator;
        }

        void f_main() {
            NumN input_size = 128;
            NumN state_size = 40;
            NumN output_size = 128;
            NumR param_scale = 0.01;
            auto params_point = create_ad_rnn_params(input_size, state_size, output_size, param_scale);
            ad_point data_inputs, data_targets;
            ad_rnn_log_likelihood(params_point, data_inputs, data_targets,
                                  input_size, state_size, output_size);
        }
    }
}