/* Copyright 2015 The math21 Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/

#include "functions_01/files.h"
#include "differential.h"

namespace math21 {
    namespace ad {
        /*
1. dual space
[https://sites.math.northwestern.edu/~scanez/courses/334/notes/dual-spaces.pdf]
[Linear Algebra Done Right, 3rd ed. by Axler]
1. automatic differentiation
Chapter 4 of [Dougal's PhD thesis](https://dougalmaclaurin.com/phd-thesis.pdf)
[talk by Matt at the Deep Learning Summer School, Montreal 2017](http://videolectures.net/deeplearning2017_johnson_automatic_differentiation/).
[Autograd](https://github.com/HIPS/autograd)
[JAX](https://github.com/google/jax)

1 given a function f: R^m -> R^n, with Jacobian function J: R^m -> R^(n*m),
then
function JVP: (R^m, R^m) -> R^n defined as JVP(x, g) = J(x)*g,
function VJP: (R^m, R^n) -> R^m defined as VJP(x, g) = g.trans*J(x).
function JMP: (R^m, R^(m*l)) -> R^n defined as JMP(x, G) = J(x)*G,
function MJP: (R^m, R^(l*n)) -> R^n defined as MJP(x, G) = G*J(x),
1 function f can be defined as a class, and function JVP can be defined as another class, or just as a method of class f.
1 JVP and VJP can be used to compute higher order derivatives.
  JMP and MJP can be used to compute first order derivatives.
1 Any numerical types other than vector must map to a vector space R^D in order to use ad.
1 Directional derivative is a generalization of partial derivative.
1 function JVP(x, *) is the directional derivative of f at x.
let f: V -> W,
then
1) JVP: (V, V) -> W, JVP(x, a) = lim (f(x+alpha*a) - f(x))/alpha, alpha -> 0
here alpha in R, x, a, in V
2) VJP: (V, W^*) -> V^*, VJP(x, b^*)(a) := b^* JVP(x, a), where x, a in V, b^* in W^*
V^* is dual space of V

1. use dependent inputs not all inputs as dependency to speed up.
1. use global object rather than function???
1. use tapes rather than global graph to speed up.
1. use template class to make defining new function cr easier.
1. cr, jvp, vjp
1. make ad backend-independent.
1. write computation graph visualization, see https://github.com/hips/autograd/blob/master/examples/dot_graph.py
1. consider autograd.test_util.check_grads
         * */

        class adtoposort {
        private:
            const VariableMap &data;
            Map child_counts;
            Seqce<NumN> childless_nodes;

            void compute(NumN y) {
                Seqce<NumN> stack;
                stack.push(y);
                while (!stack.isEmpty()) {
                    NumN x = stack.getLast();
                    stack.removeLast();
                    if (child_counts.has(x)) {
                        child_counts.valueAt(x) += 1;
                    } else {
                        child_counts.add(x, 1);
                        stack.push(data(x).getX());
                    }
                }
                childless_nodes.push(y);
            }

        public:
            adtoposort(NumN y, const VariableMap &data) : data(data) {
                compute(y);
            }

            NumN next() {
                if (childless_nodes.isEmpty()) {
                    return 0;
                }
                NumN y = childless_nodes.getLast();
                childless_nodes.removeLast();
                const Set &X = data(y).getX();
                for (NumN i = 1; i <= X.size(); ++i) {
                    NumN x = X(i);
                    if (child_counts.valueAt(x) == 1) {
                        childless_nodes.push(x);
                    } else {
                        child_counts.valueAt(x) -= 1;
                    }
                }
                return y;
            }
        };

        /*
 *
 def backward_pass(g, end_node):
    outgrads = {end_node : (g, False)}
    for node in toposort(end_node):
        outgrad = outgrads.pop(node)
        ingrads = node.vjp(outgrad[0])
        for parent, ingrad in zip(node.parents, ingrads):
            outgrads[parent] = add_outgrads(outgrads.get(parent), ingrad)
    return outgrad[0]

 * */

        // todo: try to optimize
        // Map DT, differential table
        void Derivative::_cd_inc(NumN y0, Map &DT, NumN mode) {
//            DT.clear();
            adtoposort toposort(y0, data);
            std::string y_name = data.at(y0).getName();
            NumN dy0;
            if (!DT.get(y0, dy0)) {
                if (mode == derivative_mode_dbr_vjp) {
                    MATH21_ASSERT(data(y0).getValue().size() == 1,
                                  "Variable " << data(y0).getName() << " must be num when using vjp mode.");
                    dy0 = ad_global_get_constant_1();
                } else {
                    MATH21_ASSERT(0)
                }
                data.at(dy0).setName(math21_string_concatenate("d(", y_name, ")/d(self)").c_str());
                DT.add(y0, dy0);
            }

            while (1) {
                NumN y = toposort.next();
                if (y == 0) {
                    return;
                }
                if (data(y).getType() == variable_type_constant ||
                    data(y).getType() == variable_type_zero_derivative) {
                    continue;
                }
                NumN dy = DT.valueAt(y);
//                DT.pop(y); // add this
                if (dy == 0) {
                    continue;
                }
                const Set &X = data(y).getX();
                // getX(X, y, V);
                for (NumN i = 1; i <= X.size(); ++i) {
                    NumN xi = X(i);
                    if (data(xi).getType() == variable_type_constant ||
                        data(xi).getType() == variable_type_zero_derivative) {
                        continue;
                    }
                    // vjp for x
                    Function &f = data.at(y).getf();
                    Set output;
                    if (mode == derivative_mode_dbr_vjp) {
                        output.clear();
                        NumN dxi_part = f.cr_vjp(X, xi, y, dy, data);
                        if (dxi_part != 0) {
                            output.set(dxi_part);
                        }
                    } else {
                        MATH21_ASSERT(0)
                    }
                    if (!output.isEmpty()) {
                        NumN dxi_part = output(1);
//                        S.add(dxi);
                        if (!DT.has(xi)) {
                            op_add add0;
                            Function &add = add0;
                            NumN dxi = add.evaluate(dxi_part, data);
                            DT.add(xi, dxi);
                            data.at(dxi).setName(math21_string_to_string("dx", i).c_str());
                        } else {
                            NumN dxi = DT.valueAt(xi);
                            Function &add = data.at(dxi).getf();
                            math21_tool_assert(add.getName() == op_add().getName());
                            auto &add0 = (op_add &) add;
                            Set input;
                            input.add(dxi_part);
                            add0.evaluate_inc(input, dxi, data);
                        }
                    }
                }
            }
        }

        Derivative::Derivative(VariableMap &data) : data(data) {
            debugLevel = 0;
            _is_cd_inc = 1;
//            _is_cd_inc = 0;
        }

        Derivative::~Derivative() {
        }

        void Derivative::removeLastRecord() {
            MATH21_ASSERT(_is_cd_inc == 1);
            data.restore();
        }

        const Set &Derivative::getX(const NumN &y) {
            const Variable &vy = data(y);
            const Set &X1 = vy.getX();
            return X1;
        }

        void Derivative::getX(Set &X, const NumN &y, const Set &V) {
            const Variable &vy = data(y);
            const Set &X1 = vy.getX();
            X1.intersect(V, X);
        }

        void Derivative::getY(const NumN &x, Set &Y, const Set &V0) {
            const Variable &vx = data(x);
            const Set &Y1 = vx.getY();
            Y1.intersect(V0, Y);
        }

        template<typename GraphType>
        NumB restrictSet_pass(const Set &X, Set &V0, const Set &Y, const GraphType &f, NumN &debug_count) {
            ++debug_count;
            if (X.size() == 0) {
                return 0;
            }

            NumB flag = 0;
            NumN X_size = X.size();
            for (NumN i = 1; i <= X_size; ++i) {
                NumN x = X(i);
                if (Y.contains(x)) {
                    V0.add(x);
                    if (flag == 0) {
                        flag = 1;
                    }
                } else {
                    const Set &Y1 = f.getY(x);
                    if (restrictSet_pass(Y1, V0, Y, f, debug_count)) {
                        V0.add(x);
                        if (flag == 0) {
                            flag = 1;
                        }
                    }
                }
            }
            return flag;
        }

        struct GraphType_forward {
            const VariableMap &data;

            GraphType_forward(const VariableMap &data) : data(data) {
            }

            const Set &getY(NumN x) const {
                math21_tool_assert(0);
                return data(x).getY();
            }
        };

        struct GraphType_backward {
            const VariableMap &data;

            GraphType_backward(const VariableMap &data) : data(data) {
            }

            const Set &getY(NumN x) const {
                return data(x).getX();
            }
        };

        void Derivative::pass_forward(const Set &X, Set &V0, const Set &Y) {
            GraphType_forward forward(data);
            NumN debug_count = 0;
            restrictSet_pass(X, V0, Y, forward, debug_count);
            m21log("restrictSet_pass", debug_count);
        }

        void Derivative::pass_backward(const Set &X, Set &V0, const Set &Y) {
            GraphType_backward backward(data);
            NumN debug_count = 0;
            restrictSet_pass(Y, V0, X, backward, debug_count);
            m21log("restrictSet_pass", debug_count);
        }

        // V0 = {V |X->v->Y}
        void Derivative::restrictSet(const Set &V, Set &V0, const Set &X, const Set &Y) {
            V0.clear();
            pass_backward(X, V0, Y);
            if (0) {
                Set Vf;
                pass_forward(X, Vf, Y);
                math21_tool_assert(V0.isEqual(Vf));
            }
        }

        // debug: n, level
        NumN Derivative::cd(const NumN &x, const Set &V, const Set &V0, Map &DT, NumN mode, NumN n, NumN level) {
            if (debugLevel) {
                m21log("cd level", level);
            }
            {
                NumN y;
                if (DT.get(x, y)) {
                    return y;
                }
            }

            Set Y;
            getY(x, Y, V0);
            MATH21_ASSERT(!Y.isEmpty())

            Set S;
            Set output;
            for (NumN j = 1; j <= Y.size(); ++j) {
                NumN y = Y(j);
                NumN dy = cd(y, V, V0, DT, mode, n, level + 1);
                if (dy == 0) {
                    continue;
                }
                Set X;
                getX(X, y, V);
                Function &f = data.at(y).getf();
                if (mode == derivative_mode_dar) {
                    f.cr(X, x, y, dy, output, data);
                } else if (mode == derivative_mode_dbr) {
                    f.backward(X, x, y, dy, output, data);
                } else if (mode == derivative_mode_dbr_vjp) {
                    output.clear();
                    NumN dx = f.cr_vjp(X, x, y, dy, data);
                    if (dx != 0) {
                        output.set(dx);
                    }
                } else {
                    MATH21_ASSERT(0)
                }
                if (!output.isEmpty()) {
                    NumN dxi = output(1);
                    S.add(dxi);
                }
            }
            NumN dx;
            if (S.isEmpty()) {
                dx = 0;
            } else if (S.size() == 1) {
                dx = S(1);
            } else {
                op_add _op_add;
                Function &add = _op_add;
                if (mode == derivative_mode_dar) {
                    add.f(S, output, data);
                } else if (mode == derivative_mode_dbr) {
                    add.forward(S, output, data);
                } else if (mode == derivative_mode_dbr_vjp) {
                    output.clear();
                    NumN y_add = add.evaluate(S, data);
                    if (y_add != 0) {
                        output.set(y_add);
                    }
                } else {
                    math21_tool_assert(0);
                }
                if (!output.isEmpty()) {
                    dx = output(1);
                } else {
                    math21_tool_assert(0);
                }
            }
            DT.add(x, dx);
            return dx;
        }

        NumN Derivative::cd(NumN x, NumN y) {
            Map dX;
            Set X;
            X.add(x);
            const Set &V = data.getV();
            cds(X, y, V, dX, 1);
            return dX.valueAt(x);
        }

        NumN Derivative::backward(NumN x, NumN y) {
            Map dX;
            Set X;
            X.add(x);
            const Set &V = data.getV();
            Map DT;
            _cds(X, y, V, dX, DT, derivative_mode_dbr, 1);
            return dX.valueAt(x);
        }

        NumN Derivative::grad_with_mode(NumN x, NumN y, NumN mode) {
            Map dX;
            Set X;
            X.add(x);
            const Set &V = data.getV();
            Map DT;
            if (_is_cd_inc) {
                _cds_inc(X, y, V, dX, DT, mode, 1);
            } else {
                _cds(X, y, V, dX, DT, mode, 1);
            }
            return dX.valueAt(x);
        }

        NumN Derivative::grad_jvp(NumN x, NumN y) {
            return grad_with_mode(x, y, derivative_mode_dbr_jvp);
        }

        NumN Derivative::grad_vjp(NumN x, NumN y) {
            NumN dx = grad_with_mode(x, y, derivative_mode_dbr_vjp);
            if (dx != 0) {
            } else {
                m21warn("grad_vjp returns 0");
//                auto d = data(x).getValue().shape();
//                dx = data.createC(0, "dx");
//                data.at(dx).getValue().setSize(d);
//                data.at(dx).getValue() = 0;
            }
            return dx;
        }

        NumN Derivative::cd(NumN x, NumN y, Map &DT) {
            Map dX;
            Set X;
            X.add(x);
            const Set &V = data.getV();
            _cds(X, y, V, dX, DT, derivative_mode_dar, 1);
            return dX.valueAt(x);
        }

        // If define-by-run, then compute must be called before cds. And this makes sure graph(compute) contains graph(cds).
        // Every function will check it by calling Variable.isComputed().
        // compute derivative. Set value to constant. n is used for debug.
        // V is modified in data.
        void Derivative::cds(const Set &X, NumN y, const Set &V, Map &dX, NumN n) {
            Map DT;
            _cds(X, y, V, dX, DT, derivative_mode_dar, n);
        }

        void Derivative::_cds(const Set &X, NumN y, const Set &V, Map &dX, Map &DT, NumN mode, NumN n) {
            if (y == 0) {
                m21log("Compute null function!");
                return;
            }

            dX.clear();

            std::string y_name = data.at(y).getName();
            Set V0;
            Set Y;
            Y.add(y);
            restrictSet(V, V0, X, Y);

            NumN dy;
            if (!DT.get(y, dy)) {
                op_mat_eye mat_eye0;
                Function &mat_eye = mat_eye0;
                if (mode == derivative_mode_dar) {
                    mat_eye.f(y, dy, data);
                } else if (mode == derivative_mode_dbr) {
                    mat_eye.forward(y, dy, data);
                } else if (mode == derivative_mode_dbr_vjp) {
                    MATH21_ASSERT(data(y).getValue().size() == 1,
                                  "Variable " << data(y).getName() << " must be num when using vjp mode.");
                    dy = ad_global_get_constant_1();
                } else {
                    MATH21_ASSERT(0)
                }
                data.at(dy).setName(math21_string_concatenate("d(", y_name, ")/d(self)").c_str());
                DT.add(y, dy);
            }

            NumN level = 1;
            Set X_connected;
            X.intersect(V0, X_connected);
            for (NumN i = 1; i <= X_connected.size(); ++i) {
                cd(X_connected(i), V, V0, DT, mode, n, level);
            }
            DT.restrictTo(X_connected, dX);

            Set X0;
            Set X1;
            dX.getX(X1);
//            math21_convert_container_to_set(dX.getX(), X1);
            X.difference(X1, X0);
            if (!X0.isEmpty()) {
                for (NumN i = 1; i <= X0.size(); ++i) {
                    dX.add(X0(i), 0);
                }
            }
        }

        void Derivative::_cds_inc(const Set &X, NumN y, const Set &V, Map &dX, Map &DT, NumN mode, NumN n) {
            data.backup();
            if (y == 0) {
                m21log("Compute null function!");
                return;
            }

            dX.clear();

            std::string y_name = data.at(y).getName();
//            Set V0;
//            Set Y;
//            Y.add(y);
//            restrictSet(V, V0, X, Y);

            NumN dy;
            if (!DT.get(y, dy)) {
                op_mat_eye mat_eye0;
                Function &mat_eye = mat_eye0;
                if (mode == derivative_mode_dar) {
                    mat_eye.f(y, dy, data);
                } else if (mode == derivative_mode_dbr) {
                    mat_eye.forward(y, dy, data);
                } else if (mode == derivative_mode_dbr_vjp) {
                    MATH21_ASSERT(data(y).getValue().isScalar(),
                                  "Variable " << data(y).getName() << " must be num when using vjp mode.");
                    dy = ad_global_get_constant_1();
                } else {
                    MATH21_ASSERT(0)
                }
                data.at(dy).setName(math21_string_concatenate("d(", y_name, ")/d(self)").c_str());
                DT.add(y, dy);
            }

            NumN level = 1;
//            Set X_connected;
//            X.intersect(V0, X_connected);
            _cd_inc(y, DT, mode);
//            DT.restrictTo(X_connected, dX);
            DT.restrictTo(X, dX);

            Set X0;
            Set X1;
            dX.getX(X1);
            X.difference(X1, X0);
            if (!X0.isEmpty()) {
                for (NumN i = 1; i <= X0.size(); ++i) {
                    dX.add(X0(i), 0);
                }
            }
        }

        // X: input
        void Derivative::fv(const Set &X, NumN y, NumN mode, NumN level) {
            if (debugLevel) {
                m21log("fv level", level);
            }
            if (y == 0) {
                m21log("Compute function value with f=0!");
                return;
            }
            if (data(y).isComputed()) {
                return;
            }
            // Element in X is considered as input even through its type may not be the input type.
            if (X.contains(y)) {
                return;
            }
            NumN type = data.at(y).getType();
            if (type == variable_type_constant || type == variable_type_input) {
                return;
            }
            const Set &X0 = getX(y);
            for (NumN i = 1; i <= X0.size(); ++i) {
                NumN x = X0(i);
                fv(X, x, mode, level + 1);
            }
            Function &f = data.at(y).getf();
            Set Y;
            Y.add(y);
            if (mode == derivative_mode_dar) {
                f.fv(data(y).getX(), Y, data);
            } else if (mode == derivative_mode_dar_dbr) {
                f.compute(data(y).getX(), Y, data, *this);
            } else {
                MATH21_ASSERT(0)
            }
            // todo: use the following and remove setComputed(1) in every specific function
            if (!data(y).isComputed()) {
                data.at(y).setComputed(1);
            }
        }

        // compute function values where no variable size in program level will be considered.
        void Derivative::fvs(const Set &X, const Set &Y) {
            for (NumN i = 1; i <= data.size(); ++i) {
                data.at(i).setComputed(0);
            }
            for (NumN i = 1; i <= Y.size(); ++i) {
                fv(X, Y(i), derivative_mode_dar);
            }
        }

        void Derivative::compute(NumN y) {
            Set X;
            fv(X, y, derivative_mode_dar_dbr);
        }

        void Derivative::compute(const Set &X, NumN y) {
            fv(X, y, derivative_mode_dar_dbr);
        }

        // compute function values where no variable size in program level will be considered.
        void Derivative::compute(const Set &X, const Set &Y, const Set &V, NumB isReset) {
            if (isReset) {
                for (NumN i = 1; i <= data.size(); ++i) {
                    data.at(i).setComputed(0);
                }
            }
            for (NumN i = 1; i <= Y.size(); ++i) {
                fv(X, Y(i), derivative_mode_dar_dbr);
            }
        }

        void Derivative::setDebugLevel(NumN debugLevel0) {
            debugLevel = debugLevel0;
        }

        VariableMap &Derivative::getData() {
            return data;
        }
    }
}