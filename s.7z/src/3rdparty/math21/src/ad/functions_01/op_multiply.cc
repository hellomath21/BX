/* Copyright 2015 The math21 Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/

#include "op_broadcast_num_to_vec.h"
#include "op_multiply.h"

namespace math21 {
    namespace ad {
        NumN op_multiply::cr_vjp_inner(const Set &X, NumN x, NumN y, NumN dy, VariableMap &data) const {
            math21_tool_assert(X.size() >= 2);
            math21_tool_assert(X.contains(x));
            Set X_no_x;
            X.copyToNox(X_no_x, x);

            Set X_mul;
            X_mul.add(dy);
            X_mul.add(X_no_x);

            op_multiply multiply0;
            Function &multiply = multiply0;
            return multiply.evaluate(X_mul, data);
        }

        // todo: add ad_is_containing_constant_num_0
        NumN op_multiply::evaluate(const Set &X0, VariableMap &data) {
            math21_tool_assert(X0.size() >= 2);
            Set X;
            broadcast_num_to_vec(X0, X, data);
            NumN y = data.createV(math21_string_concatenate(getName(), "(x)").c_str());
            data.at(y).setf(this);
            data.at(y).setX(X);
            for (NumN i = 1; i <= X.size(); ++i) {
                data.at(X(i)).addy(y);
            }
            Set Y;
            Y.add(y);
            fv(X, Y, data);
            return y;
        }

        void op_multiply::fv(const Set &X, const Set &Y, VariableMap &data) const {
            NumN y = Y(1);
            variable_setSize_to_same_vspace_using_variable(X(1), y, data);
            auto &y_vec = data.at(y).getValue();
            y_vec = 1;
            NumN n = y_vec.size();
            for (NumN i_X = 1; i_X <= X.size(); ++i_X) {
                NumN x = X(i_X);
                const auto &x_vec = data.at(x).getValue();
                for (NumN i = 1; i <= n; ++i) {
                    y_vec.at(i) = xjmultiply(y_vec.at(i), x_vec(i));
                }
            }
        }
    }
}