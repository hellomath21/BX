/* Copyright 2015 The math21 Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/

#include "num_multiply.h"
#include "num_sin.h"
#include "num_cos.h"
#include "inner_cc.h"

namespace math21 {
    namespace ad {
        op_num_sin::op_num_sin() {
        }

        op_num_sin::~op_num_sin() {
        }

        void op_num_sin::df(const Set &X, NumN x, NumN y, NumN &dydx, VariableMap &data) const {
            if (X(1) != x) {
                dydx = ad_global_get_constant_0();
                return;
            }

            NumN y_cos;
            op_num_cos cos0;
            Function& cos = cos0;
            cos.f(x, y_cos, data);
            dydx = y_cos;
        }

        void op_num_sin::df_dbr(const Set &X, NumN x, NumN y, NumN &dydx, VariableMap &data) const {
            if (X(1) != x) {
                dydx = ad_global_get_constant_0();
                return;
            }

            NumN y_cos;
            op_num_cos cos0;
            Function& cos = cos0;
            cos.forward(x, y_cos, data);
            dydx = y_cos;
        }

        NumR op_num_sin::evaluate_at_num(NumR x) const {
            return xjsin(x);
        }

        Function *op_num_sin::clone() const {
            Function *f = new op_num_sin();
            return f;
        }

        const char *op_num_sin::getName() const {
            return "op_num_sin";
        }
    }
}