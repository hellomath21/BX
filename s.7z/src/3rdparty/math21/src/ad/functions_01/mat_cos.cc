/* Copyright 2015 The math21 Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/

#include "inner_cc.h"
#include "vec_multiply.h"
#include "mat_sin.h"
#include "mat_cos.h"

namespace math21 {
    namespace ad {
        op_mat_cos::op_mat_cos() {
        }

        op_mat_cos::~op_mat_cos() {
        }

        void op_mat_cos::cr(const Set &X, NumN x, NumN y, NumN dy, Set &output, VariableMap &data) const {

            op_mat_sin sin;
            sin.f(X, output, data);
            data.at(output(1)).setName("-d(cos(x))");

            NumN k = data.createC(-1, "-1");
            if(isSetSize()){
                setSizeyByx(X(1), k, data);
            }
            Set input;
            input.add(k);
            input.add(dy);
            input.add(output);
            op_vec_multiply multiply;
            multiply.f(input, output, data);
            data.at(output(1)).setName("dx = (-1) * dy * (-d(cos(x)))");
        }

        void op_mat_cos::f(const Set &X, Set &output, VariableMap &data) {
            NumN x = X(1);
            NumN y = data.createV("cos(x)");
            if(isSetSize()){
                setSizeyByx(x, y, data);
            }
            data.at(y).setf(this);
            data.at(y).addx(x);
            data.at(x).addy(y);
            output.clear();
            output.add(y);
        }

        void op_mat_cos::fv(const Set &X, const Set &Y, VariableMap &data) const {
            NumN y = Y(1);
            if(data.at(y).isComputed()){
                return;
            }
            math21_operator_cos(data(X(1)).getValue(), data.at(y).getValue());
            data.at(y).setComputed(1);
        }

        void op_mat_cos::setSize(const Set &X, const Set &Y, VariableMap &data) const {
            setSizeYByX(X, Y, data);
        }

        Function *op_mat_cos::clone() const {
            Function *f = new op_mat_cos();
            return f;
        }

        const char *op_mat_cos::getName() const {
            return "op_mat_cos";
        }
    }
}