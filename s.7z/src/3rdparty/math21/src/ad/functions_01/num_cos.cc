/* Copyright 2015 The math21 Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/

#include "num_multiply.h"
#include "num_sin.h"
#include "num_cos.h"
#include "inner_cc.h"

namespace math21 {
    namespace ad {
        op_num_cos::op_num_cos() {
        }

        op_num_cos::~op_num_cos() {
        }

        void op_num_cos::df(const Set &X, NumN x, NumN y, NumN &dydx, VariableMap &data) const {
            if (X(1) != x) {
                dydx = ad_global_get_constant_0();
                return;
            }

            NumN y_sin;
            op_num_sin sin0;
            Function& sin = sin0;
            sin.f(x, y_sin, data);

            NumN k;
            k = ad_global_get_constant_m1();

            op_num_multiply multiply0;
            Function& multiply = multiply0;
            multiply.f(k, y_sin, dydx, data);
        }

        void op_num_cos::df_dbr(const Set &X, NumN x, NumN y, NumN &dydx, VariableMap &data) const {
            if (X(1) != x) {
                dydx = ad_global_get_constant_0();
                return;
            }

            NumN y_sin;
            op_num_sin sin0;
            Function& sin = sin0;
            sin.forward(x, y_sin, data);

            NumN k;
            k = ad_global_get_constant_m1();

            op_num_multiply multiply0;
            Function& multiply = multiply0;
            multiply.forward(k, y_sin, dydx, data);
        }

        NumR op_num_cos::evaluate_at_num(NumR x) const {
            return xjcos(x);
        }

        Function *op_num_cos::clone() const {
            Function *f = new op_num_cos();
            return f;
        }

        const char *op_num_cos::getName() const {
            return "op_num_cos";
        }
    }
}