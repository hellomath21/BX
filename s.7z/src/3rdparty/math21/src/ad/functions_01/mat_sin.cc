/* Copyright 2015 The math21 Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/

#include "inner_cc.h"
#include "mat_jacobian.h"
#include "op_mat_mul.h"
#include "num_sin.h"
#include "vec_multiply.h"
#include "mat_cos.h"
#include "mat_sin.h"

namespace math21 {
    namespace ad {
        NumB flag_abstract_completely = 0;

        op_mat_sin::op_mat_sin() {
        }

        op_mat_sin::~op_mat_sin() {
        }

        void op_mat_sin::cr(const Set &X, NumN x, NumN y, NumN dy, Set &output, VariableMap &data) const {
            if (flag_abstract_completely && Variable::isRequestingAbstractCompletely()) {
                if (Function::isElementWiseTest()) {
                    op_mat_cos cos;
                    cos.f(X, output, data);
                    data.at(output(1)).setName("d(sin(x))");
                    Set input;
                    input.add(dy);
                    input.add(output);
                    op_vec_multiply multiply;
                    multiply.f(input, output, data);
                    data.at(output(1)).setName("dx = dy * d(sin(x))");
                } else {
                    op_mat_dsin dsin;
                    dsin.f(X, output, data);
                    Set input;
                    input.add(dy);
                    input.add(output);
                    op_mat_mul mul;
                    mul.f(input, output, data);
                    data.at(output(1)).setName("dx = dy * d(sin(x))");
                }
            } else {
                // y must be computed in define-by-run mode.
                MATH21_ASSERT(data(y).isComputed())
                op_mat_jacobian jacobian;
                Set X_jacobian;
                X_jacobian.add(X(1));
                X_jacobian.add(y);
                jacobian.f(X_jacobian, output, data);

                Set input;
                input.add(dy);
                input.add(output);
//                MATH21_ASSERT(0)
                op_mat_mul mul;
                mul.f(input, output, data);
                data.at(output(1)).setName("dx = dy * d(sin(x))");
            }
        }

        void op_mat_sin::f(const Set &X, Set &output, VariableMap &data) {
            NumN x = X(1);
            NumN y = data.createV("sin(x)");
            if (isSetSize()) {
                setSizeyByx(x, y, data);
            }
            data.at(y).setf(this);

            data.at(y).addx(x);
            data.at(x).addy(y);
            output.clear();
            output.add(y);
        }

        void op_mat_sin::fv(const Set &X, const Set &Y, VariableMap &data) const {
            NumN y = Y(1);
            if (data.at(y).isComputed()) {
                return;
            }
            const auto &x_mat = data(X(1)).getValue();
            auto &y_mat = data.at(y).getValue();
            if (y_mat.size() != x_mat.size()) {
                y_mat.setSize(x_mat.shape());
            }
            math21_operator_sin(x_mat, y_mat);
            data.at(y).setComputed(1);
        }

        void op_mat_sin::compute(const Set &X, const Set &Y, VariableMap &data, Derivative &derivative) {
            if (flag_abstract_completely && Variable::isRequestingAbstractCompletely()) {
                fv(X, Y, data);
                return;
            }
            NumN x = X(1);
            NumN y = Y(1);
            if (data.at(y).isComputed()) {
                return;
            }
            const auto &x_mat = data(x).getVariableMat();
            if (data.at(y).isAbstractCompletely()) {
                data.at(y).setAbstractZero();
                auto &y_mat = data.at(y).getVariableMat();
                if (y_mat.size() != x_mat.size()) {
                    y_mat.setSize(x_mat.shape());
                }
                for (NumN i = 1; i <= x_mat.size(); ++i) {
                    op_num_sin num_sin;
                    Function &function = num_sin;
                    NumN y_sin;
                    function.f(x_mat(i), y_sin, data);
                    std::string name = math21_string_concatenate(getName(), math21_string_to_string(i), "(x)");
                    data.at(y_sin).setName(name.c_str());
                    y_mat.at(i) = y_sin;
                }
            }
            auto &y_mat = data.at(y).getVariableMat();
            MATH21_ASSERT(y_mat.size() == x_mat.size())
            for (NumN i = 1; i <= x_mat.size(); ++i) {
                Function &function = data.at(y_mat(i)).getf();
                function.compute(x_mat(i), y_mat(i), data, derivative);
            }
            data.at(y).synchronizeValue(data);
            data.at(y).setComputed(1);
        }

        Function *op_mat_sin::clone() const {
            Function *f = new op_mat_sin();
            return f;
        }

        const char *op_mat_sin::getName() const {
            return "op_mat_sin";
        }
    }

    namespace ad {
        op_mat_dsin::op_mat_dsin() {
        }

        op_mat_dsin::~op_mat_dsin() {
        }

        void op_mat_dsin::cr(const Set &X, NumN x, NumN y, NumN dy, Set &output, VariableMap &data) const {
            MATH21_ASSERT(0);
        }

        void op_mat_dsin::f(const Set &X, Set &output, VariableMap &data) {
            NumN x = X(1);
            NumN y = data.createV(math21_string_concatenate(getName(), "(x)").c_str());
            data.at(y).setf(this);

            data.at(y).addx(x);
            data.at(x).addy(y);
            output.clear();
            output.add(y);
        }

        void op_mat_dsin::fv(const Set &X, const Set &Y, VariableMap &data) const {
            NumN x = X(1);
            NumN y = Y(1);
            const auto &x_vec = data(x).getValue();
            auto &y_mat = data.at(y).getValue();
            auto n = x_vec.size();
            y_mat.setSize(n, n);
            y_mat = 0;
            for (NumN i = 1; i <= n; ++i) {
                y_mat.operator()(i, i) = xjcos(x_vec(i));
            }
        }

        Function *op_mat_dsin::clone() const {
            Function *f = new op_mat_dsin();
            return f;
        }

        const char *op_mat_dsin::getName() const {
            return "op_mat_dsin";
        }
    }
}