/* Copyright 2015 The math21 Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/

#pragma once

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <math.h>
#include <assert.h>
#include "config/clvector.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef uint8_t NumN8;
typedef int8_t NumZ8; // 8 bit integer
typedef uint32_t NumN32;
typedef int32_t NumZ32; // 32 bit integer
typedef uint64_t NumN64;
typedef int64_t NumZ64;
typedef NumN64 NumSize;

// Type used:
typedef NumZ32 NumZ;
typedef NumN32 NumN;
typedef double NumR; // default floating type
typedef float NumFloat; // tmp name
typedef double NumDouble; // tmp name

// Type not used
typedef NumN32 NumB;

#ifndef MATH21_FLAG_USE_OPENCL
typedef const float *PointerFloatInputWrapper;
typedef float *PointerFloatWrapper;
typedef float *PointerFloatGpu; // always is gpu vector
typedef const int *PointerIntInputWrapper;
typedef int *PointerIntWrapper;
typedef const NumN8 *PointerN8InputWrapper;
typedef NumN8 *PointerN8Wrapper;
typedef void *PointerVoidWrapper;
#else
//typedef const float * PointerFloatInputWrapper;
//typedef float *PointerFloatWrapper;
//typedef float *PointerFloatGpu; // always is gpu vector
//typedef const int *PointerIntInputWrapper;
//typedef int *PointerIntWrapper;
//typedef const NumN8 *PointerN8InputWrapper;
//typedef NumN8 *PointerN8Wrapper;
//typedef void *PointerVoidWrapper;

typedef m21clvector PointerFloatInputWrapper;
typedef m21clvector PointerFloatWrapper;
typedef m21clvector PointerFloatGpu; // always is gpu vector
typedef m21clvector PointerIntInputWrapper;
typedef m21clvector PointerIntWrapper;
typedef m21clvector PointerN8InputWrapper;
typedef m21clvector PointerN8Wrapper;
typedef m21clvector PointerVoidWrapper;
#endif

// define specifier
#define NumSize_SPECIFIER    "%llu"
#if defined(_MSC_VER) || defined(__MINGW32__) //__MINGW32__ should goes before __GNUC__
#define SIZE_T_SPECIFIER    "%Iu"
#elif defined(__GNUC__)
#define SIZE_T_SPECIFIER    "%zu"
#else
#define SIZE_T_SPECIFIER    "%u"
#endif

#if defined(MATH21_FLAG_USE_CPU)
#define M21_EXPORT
#elif defined(MATH21_FLAG_USE_CUDA)
#define M21_EXPORT __host__ __device__
#elif defined(MATH21_FLAG_USE_OPENCL)
#define M21_EXPORT
#endif


#define MATH21_TIME_MAX (10000000)
#define MATH21_OPT_TIME_MAX (10000000)
#define XJ_TRUE 1
#define XJ_FALSE 0

#define MATH21_EPS2 (1e-10)
#define MATH21_EPS (0.000001)
#define MATH21_10NEG6 (0.000001)
#define MATH21_10NEG7 (0.0000001)
#define MATH21_EPS_NEG (-0.000001)
#define XJ_EPS (0.000001)
#define XJ_PI (3.14159265357989323)
#define XJ_TWO_PI 6.2831853071795864769252866f
#define XJ_MAX (10000000)
#define XJ_MIN (-10000000)
#define MATH21_GPU_BLOCK_SIZE 16
#define MATH21_CUDA_BLOCK_SIZE 512 // number of threads per dimension of block
#define MATH21_OPENCL_BLOCK_SIZE 512 // meaning different from that of cuda
#define MATH21_DIMS_RAW_TENSOR 3 // used by rawtensor
#define MATH21_DIMS_MAX_RAW_TENSOR 8 // used by rawtensor
#define MATH21_MASK_NUM 212121
#define math21_tool_assert(exp) assert(exp)
#define math21_raise(exp) assert(exp)
#define math21_tool_assert_to_do_remove(exp) assert(exp)

// debug
//#ifdef fprintf
//#undef fprintf
//#endif
//#define fprintf(X, ...) {}

enum {
    m21_type_none = 0,
    m21_type_default,
    m21_type_NumN,
    m21_type_NumZ,
    m21_type_NumR,
    m21_type_Seqce,
    m21_type_Tensor,
    m21_type_Digraph,
    m21_type_vector_float_c,
    m21_type_vector_char_c,
    m21_type_NumFloat,
    m21_type_TenN,
    m21_type_TenZ,
    m21_type_TenR,
    m21_type_ad_point,
};

// object, not similar to std::shared_ptr
typedef struct m21point m21point;
struct m21point {
    NumN type; // type of data element in math21_type
    void *p; // pointer pointing to object.
};

// todo: deprecate, use 'm21point + tensor' instead.
typedef struct m21rawtensor m21rawtensor;
struct m21rawtensor {
    NumN type; // type of data element in math21_type
    NumN dims;
    NumN *d; // pointer to data address of Tensor shape, or sth created by user.
    void *data; // pointer to data address of Tensor, or sth created by user.
};

typedef struct {
    NumN nr;
    NumN nc;
    NumN nch;
    NumFloat *data; // data shape: nch * nr * nc
} m21image;

#ifdef __cplusplus
}
#endif
